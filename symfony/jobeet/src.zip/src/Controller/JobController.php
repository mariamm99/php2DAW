<?php
namespace App\Controller;

use App\Entity\Category;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Job;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Response;
use App\Repository\CategoryRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Entity;

/**
 * @Route("job")
 * 
 */
class JobController extends AbstractController
{
    /**
     * @Route("/", name="job.list")
     * @Entity("category", expr="repository.findWithActiveJobs()")
     *
     * @param Job $job
     *
     * @return Response
     */
    public function list(EntityManagerInterface $em) : Response {
      $categories = $em->getRepository(Category::class)->findWithActiveJobs();
        return $this->render('job/list.html.twig', ['categories' => $categories]);
    }

     /**
     * Finds and displays a job entity.
     *
     * @Route("job/{id}", name="job.show", methods="GET", requirements={"id" = "\d+"})
     *
     * @Entity("job", expr="repository.findActiveJob(id)")
     *
     * @param Job $job
     *
     * @return Response
     */
    public function show(Job $job) : Response {
      return $this->render('job/show.html.twig', ['job' => $job]);
  }




}
